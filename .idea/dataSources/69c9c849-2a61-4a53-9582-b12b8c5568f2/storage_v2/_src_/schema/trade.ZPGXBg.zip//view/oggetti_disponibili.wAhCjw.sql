create definer = root@localhost view oggetti_disponibili as
select `trade`.`oggetto`.`id`            AS `id_oggetto`,
       `trade`.`utente`.`id`             AS `id_utente`,
       `trade`.`oggetto`.`nome`          AS `nome`,
       `trade`.`oggetto`.`data_offerta`  AS `data_offerta`,
       `trade`.`utente`.`nome`           AS `nomeu`,
       `trade`.`utente`.`cognome`        AS `cognomeu`,
       `trade`.`categoria`.`descrizione` AS `categoria`
from `trade`.`oggetto`
         join `trade`.`utente`
         join `trade`.`categoria`
where `trade`.`utente`.`id` = `trade`.`oggetto`.`id_offerente`
  and `trade`.`categoria`.`id` = `trade`.`oggetto`.`id_categoria`
  and `trade`.`oggetto`.`data_scambio` is null;

