create definer = root@localhost view ogg_off as
select `trade`.`oggetto`.`id`             AS `id_oggetto`,
       `trade`.`oggetto`.`id_offerente`   AS `id_offerente`,
       `trade`.`oggetto`.`nome`           AS `nome`,
       `trade`.`oggetto`.`data_offerta`   AS `data_offerta`,
       `trade`.`oggetto`.`data_scambio`   AS `data_scambio`,
       `trade`.`categoria`.`descrizione`  AS `categoria`,
       `trade`.`oggetto`.`id_richiedente` AS `id_richiedente`
from `trade`.`utente`
         join `trade`.`categoria`
         join `trade`.`oggetto`
where `trade`.`utente`.`id` = `trade`.`oggetto`.`id_offerente`
  and `trade`.`categoria`.`id` = `trade`.`oggetto`.`id_categoria`;

