create definer = root@localhost view oggetti_disponibili as
select `market`.`oggetto`.`id`            AS `id_oggetto`,
       `market`.`utente`.`id`             AS `id_utente`,
       `market`.`oggetto`.`nome`          AS `nome`,
       `market`.`categoria`.`descrizione` AS `categoria`,
       `market`.`oggetto`.`data_offerta`  AS `data_offerta`,
       `market`.`utente`.`nome`           AS `nomeu`,
       `market`.`utente`.`cognome`        AS `cognomeu`
from `market`.`oggetto`
         join `market`.`categoria`
         join `market`.`utente`
where `market`.`oggetto`.`id_categoria` = `market`.`categoria`.`id`
  and `market`.`oggetto`.`id_offerente` = `market`.`utente`.`id`
  and `market`.`oggetto`.`data_scambio` is null;

